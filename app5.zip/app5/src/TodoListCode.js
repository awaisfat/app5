import React, { useEffect, useState,useMemo } from 'react'
import debounce from "lodash.debounce";

export default function TodoListCode() {
    const [search, setSearch]=useState("");
    const [filteredRecord, setFilteredRecord]=useState([]);
    const [value, setValue]=useState();
    const [original, setOriginal]=useState([]);
    

    const handleChange=(e)=>{
        setValue(e.target.value);
        
    }
    

    // handle todo code
    

const handleSUbmit=(e)=>{
 
  e.preventDefault();
    setValue("");
    setFilteredRecord([...filteredRecord,  {index:value ,title:value}]);
    setOriginal([...filteredRecord, {title:value}])
   
}


// filter code
const handleSearching=()=>{
 
  if(search===""){
    setFilteredRecord(original);

  }
  else{
    setFilteredRecord(filteredRecord.filter((match)=>match.title.toLowerCase().includes(search.toLowerCase())))
  }
}


useEffect(()=>{
  handleSearching();
},[search, setSearch])


const debounceGetLeads = useMemo(
  () => debounce((filter) => setSearch(filter), 500),
  [],
);






  return (
    <>
    <header>
    <div className='searchParent'>
    <nav className='navbar'>
<ul>
  <li><a href="#"> Home</a></li>
  <li><a href="#">About</a></li>
</ul>
 </nav>
    
   <div className='inputWraper'>
 <input type="input" className='searchINpput' onChange={(e)=>debounceGetLeads(e.target.value)}/>
   </div>
  
    </div>
    </header>

        <div className='todo_parent'>
          <h2 className='h3'>Write here</h2>
      
       
      <form className='inputAndButton' onSubmit={handleSUbmit}>
      <input type="text" className="inputText" onChange={handleChange} value={value}/>
       <button type="submit" className="btn btn-sm btn-white">
          Submit
        </button>
      </form>
       
     <div>
      <hr />
        <h3 className='black'>Render List Here</h3>
        <hr />
     
     </div>
    </div>

    <div className="MainCard">
    {
      search === "" ? (
        <div >
        {filteredRecord?.map((item, index)=>(
          <>
          <div key={index} className="card">
          <div>{item?.title}</div>
          <button type='button' className='delButton' >Delete</button>
          </div>
          </>
       ))}
      
        </div>
      ): search !==""?(
        <div>
      {filteredRecord?.map((item, index)=>(
        <>
        <div key={index} className="card">
        <div>{item?.title}</div>
        </div>
        </>
     ))}
    
      </div>
      ):null 
      
     
     }
    </div>
    </>
  )
}
