import "./App.css";
import TodoListCode from "./TodoListCode";


function App() {
  

  
  return (
    <>
      <div className="main_container">
        <TodoListCode/>
        </div>
    </>
  );
 
}


export default App;